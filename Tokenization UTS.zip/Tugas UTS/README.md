# UTS Big Data

Nama      : Moch Yopi Annas</br>
NIM       : B34180028</br>
Prodi     : Teknik Informatika 2018 A</br>

